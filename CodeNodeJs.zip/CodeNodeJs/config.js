const token = "ASCQdtWhIbPTIfpuIx8E0MifNH6--mk3qa7vtyegfD_STqoIvdDW9WZys07HzvOkttRi4y0R3XuiPEiwWmy-qQ=="

module.exports = token;