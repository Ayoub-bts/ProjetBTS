import mqtt from 'mqtt';
import { InfluxDBClient, Point } from '@influxdata/influxdb3-client';

const brokerUrl = 'mqtts://tebebeeb.ala.eu-central-1.emqxsl.com:8883';
const mqttOptions = {
  username: 'BTSESP',
  password: '123',
};

// Connexion
const mqttClient = mqtt.connect(brokerUrl, mqttOptions);
const influxClient = new InfluxDBClient({
  host: 'https://eu-central-1-1.aws.cloud2.influxdata.com',
  token: 'ASCQdtWhIbPTIfpuIx8E0MifNH6--mk3qa7vtyegfD_STqoIvdDW9WZys07HzvOkttRi4y0R3XuiPEiwWmy-qQ==',
});
const database = 'LocalViticole';

let lastTemperature = null;
let lastHumidite = null;

mqttClient.on('connect', () => {
  console.log('✅ Connecté à EMQX Cloud MQTT');
  mqttClient.subscribe(['esp32/temp', 'esp32/hum'], (err) => {
    if (!err) {
      console.log('📡 Abonné aux topics esp32/temp & esp32/hum');
    } else {
      console.error('❌ Erreur abonnement MQTT:', err);
    }
  });
});

mqttClient.on('message', async (topic, message) => {
  try {
    const msg = message.toString();
    console.log(`📥 Reçu sur ${topic}: ${msg}`);

    const valueMatch = msg.match(/value=([\d.]+)/);
    if (!valueMatch) {
      console.warn('⚠️ Message invalide (pas de valeur trouvée)');
      return;
    }
    const value = parseFloat(valueMatch[1]);

    if (topic === 'esp32/temp') {
      lastTemperature = value;
    } else if (topic === 'esp32/hum') {
      lastHumidite = value;
    }

    if (lastTemperature !== null && lastHumidite !== null) {
      const point = new Point('mesures')
        .floatField('temperature', lastTemperature)
        .floatField('humidite', lastHumidite)
        .timestamp(new Date());
    
      await influxClient.write(point, database);
      console.log('📤 Données envoyées à InfluxDB:', {
        temperature: lastTemperature,
        humidite: lastHumidite,
      });
    
      lastTemperature = null;
      lastHumidite = null;
    }
    
  } catch (err) {
    console.error('❌ Erreur traitement MQTT:', err.message);
  }
});
