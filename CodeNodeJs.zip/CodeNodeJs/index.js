import {InfluxDBClient, Point} from '@influxdata/influxdb3-client'
//const token = import('./config');


async function main() {
    const client = new InfluxDBClient({host: 'https://eu-central-1-1.aws.cloud2.influxdata.com', token: "ASCQdtWhIbPTIfpuIx8E0MifNH6--mk3qa7vtyegfD_STqoIvdDW9WZys07HzvOkttRi4y0R3XuiPEiwWmy-qQ=="})

    let database = `LocalViticole`
    const points =
    [
        Point.measurement("census")
            .setTag("location", "Klamath")
            .setIntegerField("bees", 23),
        Point.measurement("census")
            .setTag("location", "Portland")
            .setIntegerField("ants", 30),
        Point.measurement("census")
            .setTag("location", "Klamath")
            .setIntegerField("bees", 28),
        Point.measurement("census")
            .setTag("location", "Portland")
            .setIntegerField("ants", 32),
        Point.measurement("census")
            .setTag("location", "Klamath")
            .setIntegerField("bees", 29),
        Point.measurement("census")
            .setTag("location", "Portland")
            .setIntegerField("ants", 40)
    ];

for (let i = 0; i < points.length; i++) {
    const point = points[i];
    await client.write(point, database)
        // separate points by 1 second
        .then(() => new Promise(resolve => setTimeout(resolve, 1000)));
}

    client.close()
}

main()